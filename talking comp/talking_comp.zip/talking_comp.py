from gtts import gTTS
import os
import speech_recognition
import webbrowser
import subprocess

a = 0
tf = 0

# a function to make speech from audio file


def speak(audio):
    print(audio)
    gtts_en = gTTS(text=audio, lang='en', slow=False)
    gtts_en.save('speech.mp3')
    os.system('mpg123 speech.mp3')

# a function to recognize a voice command


def command():
    sr = speech_recognition.Recognizer()

    with speech_recognition.Microphone() as source:
        print('Say something')
        sr.pause_threshold = 1
        sr.adjust_for_ambient_noise(source, duration=1)
        audio = sr.listen(source)

    try:
        my_com = sr.recognize_google(audio)
        print('My command :', my_com, '\n')

    except speech_recognition.UnknownValueError:
        print('I don`t understand you!!!')
        library(command())
        return '0'

    except speech_recognition.RequestError as e:
        print('Google ERROR; {0}'.format(e))
        library(command())
        return '0'

    return my_com

# a library of commands


def library(my_com):

    # Talking to computer

    if 'hello' in my_com:
        speak('Hi')

    if 'how are you' in my_com:
        speak('Fine')

    if 'thank you' in my_com:
        speak('Your welcome')

    if 'what\'s your name' in my_com:
        speak('Emily')

    if 'cool' in my_com:
        speak('amazing')

    # game 'True or False'

    global tf

    if 'let\'s play true or false' in my_com:
        speak('okey, I say something and you must to say true it or false. It is very easy')
        tf = 1

    elif tf == 1:
        if 'begin' in my_com:
            speak('well, the cow gives milk for people')
            tf = 2
        else:
            speak('say begin to begin')

    elif tf == 2:
        if 'true' in my_com:
            speak('yes, you are right')
            tf = 3
        elif 'false' in my_com:
            speak('no, you made a mistake')
            tf = 3
        else:
            speak('say true or false')

    elif tf == 3:
        if ('continue' in my_com) or ('go on' in my_com):
            speak('well, nature has an animal which we cannot kill')
            tf = 4
        else:
            speak('say go on or continue')

    elif tf == 4:
        if 'true' in my_com:
            speak('yes, you are right, it is tihohodka')
            tf = 5
        elif 'false' in my_com:
            speak('no, you made a mistake')
            tf = 5
        else:
            speak('say true or false')

    elif tf == 5:
        if ('continue' in my_com) or ('go on' in my_com):
            speak('well, the octopus had two hearts')
            tf = 6
        else:
            speak('say go on or continue')

    elif tf == 6:
        if 'false' in my_com:
            speak('yes, you are right. Octopus has three hearts')
            speak('the end of the game')
            tf = 0
        elif 'true' in my_com:
            speak('no, you made a mistake')
            speak('the end of the game')
            tf = 0
        else:
            speak('say true or false')

    # Opening in chrome

    if 'open my marks' in my_com:
        speak('School is cool')
        chrome_path = 'C:/Program Files (x86)/Google/Chrome/Application/chrome.exe %s'
        url = 'https://schools.dnevnik.ru/marks.aspx?school=14408&index=1&tab=period&homebasededucation=False'
        webbrowser.get(chrome_path).open(url)

    if 'open music' in my_com:
        speak('I like music too')
        music_path = 'C:/Program Files (x86)/Google/Chrome/Application/chrome.exe %s'
        url = 'https://music.yandex.ru/tag/%D0%B2%D0%BE%D0%BA%D1%80%D1%83%D0%B3%20%D1%85%D0%B0%D0%B9%D0%BF?sort=popular'
        webbrowser.get(music_path).open(url)

    # Opening programs

    if 'open calculator' in my_com:
        speak('I`m opening...')
        program = 'calc.exe'
        process = subprocess.Popen(program)
        code = process.wait()
        if code == 0:
            print('Caculator is opened')
        else:
            speak('I can`t')

    # Exiting the program

    if 'goodbye' in my_com:
        speak('See you later')
        global a
        a = 1

speak('I`m ready')

while a == 0:
    library(command())
